import { ReactNode } from 'react';

export interface Option {
  text: string;
  timeMultiplier: number;
  costMultiplier: number;
  processScore?: number;
}

export interface Question {
  id: number;
  text: string;
  options: Option[];
  icon: ReactNode;
  category: 'industry' | 'processes' | 'volume' | 'communication' | 'admin';
}

export interface Savings {
  time: number;
  cost: number;
}

export interface Multipliers {
  time: number;
  cost: number;
  industry: string;
  processScore: number;
}