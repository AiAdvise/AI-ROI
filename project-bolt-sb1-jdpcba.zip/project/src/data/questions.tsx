import { Building2, ClipboardList, Users, Mail, FileSpreadsheet, PenTool, Share2 } from 'lucide-react';
import { Question } from '../types/quiz';

export const questions: Question[] = [
  {
    id: 1,
    text: "What type of local business do you operate?",
    category: 'industry',
    options: [
      { 
        text: "Retail/Shop 🏪",
        timeMultiplier: 1.2,
        costMultiplier: 1.1,
        processScore: 30
      },
      { 
        text: "Restaurant/Food Service 🍽️",
        timeMultiplier: 1.1,
        costMultiplier: 1.0,
        processScore: 25
      },
      { 
        text: "Professional Services (Legal, Accounting, etc.) 👔",
        timeMultiplier: 1.4,
        costMultiplier: 1.3,
        processScore: 40
      },
      { 
        text: "Healthcare/Medical Practice 🏥",
        timeMultiplier: 1.3,
        costMultiplier: 1.2,
        processScore: 35
      }
    ],
    icon: <Building2 className="w-8 h-8 text-indigo-500" />
  },
  {
    id: 2,
    text: "How much time do you spend on paperwork and data entry daily?",
    category: 'processes',
    options: [
      { 
        text: "4+ hours (It's endless!) 📚",
        timeMultiplier: 1.5,
        costMultiplier: 1.4,
        processScore: 40
      },
      { 
        text: "2-4 hours (Significant part of my day) 📝",
        timeMultiplier: 1.3,
        costMultiplier: 1.2,
        processScore: 30
      },
      { 
        text: "1-2 hours (Manageable but time-consuming) 📋",
        timeMultiplier: 1.2,
        costMultiplier: 1.1,
        processScore: 20
      },
      { 
        text: "Less than 1 hour (Well organized) ✓",
        timeMultiplier: 1.1,
        costMultiplier: 1.0,
        processScore: 10
      }
    ],
    icon: <FileSpreadsheet className="w-8 h-8 text-indigo-500" />
  },
  {
    id: 3,
    text: "How often do you create content for your business (social posts, emails, blog posts)?",
    category: 'content',
    options: [
      { 
        text: "Daily (Very active online presence) ✍️",
        timeMultiplier: 1.5,
        costMultiplier: 1.3,
        processScore: 35
      },
      { 
        text: "2-3 times per week (Regular updates) 📱",
        timeMultiplier: 1.3,
        costMultiplier: 1.2,
        processScore: 25
      },
      { 
        text: "Weekly (Maintaining basics) 📝",
        timeMultiplier: 1.2,
        costMultiplier: 1.1,
        processScore: 15
      },
      { 
        text: "Rarely (When I remember) 🤔",
        timeMultiplier: 1.1,
        costMultiplier: 1.0,
        processScore: 5
      }
    ],
    icon: <PenTool className="w-8 h-8 text-indigo-500" />
  },
  {
    id: 4,
    text: "How much time do you spend managing social media weekly?",
    category: 'social',
    options: [
      { 
        text: "10+ hours (Heavy social presence) 📱",
        timeMultiplier: 1.4,
        costMultiplier: 1.3,
        processScore: 30
      },
      { 
        text: "5-10 hours (Regular engagement) 💬",
        timeMultiplier: 1.3,
        costMultiplier: 1.2,
        processScore: 25
      },
      { 
        text: "2-5 hours (Basic maintenance) 📲",
        timeMultiplier: 1.2,
        costMultiplier: 1.1,
        processScore: 15
      },
      { 
        text: "Less than 2 hours (Minimal presence) 🤳",
        timeMultiplier: 1.1,
        costMultiplier: 1.0,
        processScore: 5
      }
    ],
    icon: <Share2 className="w-8 h-8 text-indigo-500" />
  },
  {
    id: 5,
    text: "How many customer inquiries/communications do you handle daily?",
    category: 'volume',
    options: [
      { 
        text: "30+ (Non-stop!) 📱",
        timeMultiplier: 1.4,
        costMultiplier: 1.3,
        processScore: 35
      },
      { 
        text: "15-30 (Busy but managing) 💬",
        timeMultiplier: 1.3,
        costMultiplier: 1.2,
        processScore: 25
      },
      { 
        text: "5-15 (Steady flow) 📨",
        timeMultiplier: 1.2,
        costMultiplier: 1.1,
        processScore: 15
      },
      { 
        text: "Less than 5 (Manageable) ✉️",
        timeMultiplier: 1.1,
        costMultiplier: 1.0,
        processScore: 5
      }
    ],
    icon: <Mail className="w-8 h-8 text-indigo-500" />
  },
  {
    id: 6,
    text: "Which administrative tasks consume most of your time?",
    category: 'admin',
    options: [
      { 
        text: "Scheduling & Calendar Management 📅",
        timeMultiplier: 1.3,
        costMultiplier: 1.2,
        processScore: 25
      },
      { 
        text: "Inventory & Supply Management 📦",
        timeMultiplier: 1.4,
        costMultiplier: 1.3,
        processScore: 30
      },
      { 
        text: "Customer Data & Records 🗄️",
        timeMultiplier: 1.3,
        costMultiplier: 1.2,
        processScore: 25
      },
      { 
        text: "Billing & Financial Tasks 💰",
        timeMultiplier: 1.4,
        costMultiplier: 1.3,
        processScore: 30
      }
    ],
    icon: <ClipboardList className="w-8 h-8 text-indigo-500" />
  },
  {
    id: 7,
    text: "How many employees do you manage?",
    category: 'communication',
    options: [
      { 
        text: "10+ (Large team) 👥",
        timeMultiplier: 1.4,
        costMultiplier: 1.3,
        processScore: 30
      },
      { 
        text: "5-10 (Growing team) 👤",
        timeMultiplier: 1.3,
        costMultiplier: 1.2,
        processScore: 25
      },
      { 
        text: "1-5 (Small team) 🤝",
        timeMultiplier: 1.2,
        costMultiplier: 1.1,
        processScore: 15
      },
      { 
        text: "Just me (Solo operation) 😊",
        timeMultiplier: 1.1,
        costMultiplier: 1.0,
        processScore: 5
      }
    ],
    icon: <Users className="w-8 h-8 text-indigo-500" />
  }
];