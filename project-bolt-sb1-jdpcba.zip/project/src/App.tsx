import React, { useState } from 'react';
import { QuizQuestion } from './components/QuizQuestion';
import { QuizResults } from './components/QuizResults';
import { questions } from './data/questions';
import { calculateSavings } from './utils/calculations';
import { Multipliers } from './types/quiz';

export default function App() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [multipliers, setMultipliers] = useState<Multipliers>({
    time: 1,
    cost: 1,
    industry: '',
    processScore: 0
  });

  const handleAnswer = (timeMultiplier: number, costMultiplier: number, processScore: number) => {
    setMultipliers(prev => ({
      ...prev,
      time: prev.time * timeMultiplier,
      cost: prev.cost * costMultiplier,
      processScore: prev.processScore + (processScore || 0),
      ...(currentQuestion === 0 ? { industry: questions[0].options[currentQuestion].text.split(' ')[0] } : {})
    }));

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      setShowResults(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setShowResults(false);
    setMultipliers({ time: 1, cost: 1, industry: '', processScore: 0 });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center p-4">
      {showResults ? (
        <QuizResults
          savings={calculateSavings(multipliers)}
          onReset={resetQuiz}
        />
      ) : (
        <QuizQuestion
          question={questions[currentQuestion]}
          currentQuestion={currentQuestion}
          totalQuestions={questions.length}
          onAnswer={handleAnswer}
        />
      )}
    </div>
  );
}