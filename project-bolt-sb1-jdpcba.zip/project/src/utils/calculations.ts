import { Multipliers, Savings } from '../types/quiz';

interface BusinessMetrics {
  baseHourlyCost: number;
  workingHoursPerWeek: number;
  baseAutomationEfficiency: number;
}

const INDUSTRY_METRICS = {
  'Retail/Shop': { costMultiplier: 1.0, automationPotential: 0.25 },
  'Restaurant/Food Service': { costMultiplier: 0.9, automationPotential: 0.2 },
  'Professional Services': { costMultiplier: 1.2, automationPotential: 0.3 },
  'Healthcare/Medical Practice': { costMultiplier: 1.1, automationPotential: 0.25 }
};

const DEFAULT_METRICS: BusinessMetrics = {
  baseHourlyCost: 25, // More realistic base employee cost for small business
  workingHoursPerWeek: 40,
  baseAutomationEfficiency: 0.4 // More conservative AI automation efficiency
};

export const calculateSavings = (multipliers: Multipliers): Savings => {
  // Adjust automation potential based on process score
  const processEfficiency = Math.min(multipliers.processScore / 200, 0.5); // More conservative efficiency cap
  
  // Calculate effective hourly cost based on industry
  const industryMetrics = INDUSTRY_METRICS[multipliers.industry as keyof typeof INDUSTRY_METRICS];
  const effectiveHourlyCost = DEFAULT_METRICS.baseHourlyCost * (industryMetrics?.costMultiplier || 1.0);
  
  // Calculate automatable hours (more conservative estimate)
  const automatableTasks = DEFAULT_METRICS.workingHoursPerWeek * (industryMetrics?.automationPotential || 0.2);
  const effectiveAutomation = automatableTasks * processEfficiency * DEFAULT_METRICS.baseAutomationEfficiency;
  
  // Calculate time savings (rounded down to be conservative)
  const timeSaved = Math.floor(effectiveAutomation * multipliers.time);
  
  // Calculate cost savings (more conservative estimate)
  const monthlyCostSaved = Math.floor(
    timeSaved * // Hours saved per week
    effectiveHourlyCost * // Industry-adjusted hourly cost
    4.33 * // Weeks per month
    multipliers.cost * // Cost multiplier from responses
    0.8 // Additional conservative factor
  );
  
  return {
    time: Math.min(timeSaved, 20), // Cap maximum weekly time savings at 20 hours
    cost: Math.min(monthlyCostSaved, 2000) // Cap maximum monthly savings at $2,000
  };
};