import React from 'react';
import { Question } from '../types/quiz';

interface QuizQuestionProps {
  question: Question;
  currentQuestion: number;
  totalQuestions: number;
  onAnswer: (timeMultiplier: number, costMultiplier: number, processScore: number) => void;
}

export function QuizQuestion({ question, currentQuestion, totalQuestions, onAnswer }: QuizQuestionProps) {
  return (
    <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8">
      <div className="flex items-center gap-4 mb-6">
        {question.icon}
        <h2 className="text-2xl font-bold text-gray-800">
          Question {currentQuestion + 1} of {totalQuestions}
        </h2>
      </div>
      
      <p className="text-xl text-gray-700 mb-8">{question.text}</p>
      
      <div className="grid gap-4">
        {question.options.map((option, index) => (
          <button
            key={index}
            onClick={() => onAnswer(option.timeMultiplier, option.costMultiplier, option.processScore || 0)}
            className="w-full text-left p-4 rounded-lg border-2 border-indigo-100 hover:border-indigo-500 
                     hover:bg-indigo-50 transition-all duration-200 text-gray-700 hover:text-indigo-700"
          >
            {option.text}
          </button>
        ))}
      </div>
      
      <div className="mt-6 w-full bg-gray-200 rounded-full h-2.5">
        <div 
          className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
          style={{ width: `${((currentQuestion + 1) / totalQuestions) * 100}%` }}
        ></div>
      </div>
    </div>
  );
}