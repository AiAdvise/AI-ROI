import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Savings } from '../types/quiz';

interface QuizResultsProps {
  savings: Savings;
  onReset: () => void;
}

export function QuizResults({ savings, onReset }: QuizResultsProps) {
  return (
    <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8">
      <h2 className="text-3xl font-bold text-gray-800 mb-6">Your AI Savings Potential</h2>
      
      <div className="space-y-8">
        <div className="bg-indigo-50 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-indigo-900 mb-2">Time Savings</h3>
          <p className="text-3xl font-bold text-indigo-700">
            {savings.time} hours <span className="text-lg font-normal text-indigo-600">per week</span>
          </p>
          <p className="mt-2 text-indigo-600">
            That's about {Math.round(savings.time * 4.33)} hours per month you could save!
          </p>
        </div>
        
        <div className="bg-purple-50 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-purple-900 mb-2">Cost Savings</h3>
          <p className="text-3xl font-bold text-purple-700">
            ${savings.cost.toLocaleString()} <span className="text-lg font-normal text-purple-600">per month</span>
          </p>
          <p className="mt-2 text-purple-600">
            That's ${(savings.cost * 12).toLocaleString()} potential savings per year!
          </p>
        </div>
        
        <div className="bg-gray-50 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">What This Means For Your Business</h3>
          <ul className="space-y-2 text-gray-700">
            <li>• Reduced manual data entry and administrative tasks</li>
            <li>• More time for strategic business growth</li>
            <li>• Improved customer response times</li>
            <li>• Better work-life balance for you and your team</li>
          </ul>
        </div>
      </div>
      
      <button
        onClick={onReset}
        className="mt-8 flex items-center gap-2 text-indigo-600 hover:text-indigo-800 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        Take the quiz again
      </button>
    </div>
  );
}